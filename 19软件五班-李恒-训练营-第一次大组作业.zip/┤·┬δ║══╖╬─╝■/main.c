/***************************************************************************************
 *	File Name				:	main.c
 *	CopyRight				:	lih
 *	SYSTEM					:   win7
 *	Create Data				:	2020.4.1
 *
 *
 *--------------------------------Revision History--------------------------------------
 *	No	version		Data			Revised By			Item			Description
 *
 *
 ***************************************************************************************/

#include "../head/main.h"

// define Type
typedef enum ListType {
	SgLinkedlist = 1,
	DbLinkedlist
} ListType;

//visit
void PrintData(ElemType e)
{
	printf("%d ", e);
}

//List arg
typedef struct List
{
	char name[12];
	ListType Type;
}List;

//Single List arg
typedef struct SgList
{
	List List;
	LinkedList HeadNode;
}SgList;

//Du List arg
typedef struct DbList
{
	List List;
	DuLinkedList HeadNode;
}DbList;

//lib
SgList SgListlib[10];
DbList DbListlib[10];
int Sg[10] = {0};
int Db[10] = {0};

Status IfOccupy(char name[11])
{
	int i;

	for(i = 0; i < 10; i ++)
	{
		if(Db[i])
		{
			if(strcmp(DbListlib[i].List.name, name) == 0)
			{
				return SUCCESS;
			}
		}
		if(Sg[i])
		{
			if(strcmp(SgListlib[i].List.name, name) == 0)
			{
				return SUCCESS;
			}
		}
	}
	return ERROR;
}

Status CreateSgList()
{
	int i;
	char name[100];
	ElemType data;
	LinkedList Head = NULL;
	LinkedList temp1, temp2 = NULL;

	for(i = 0; i < 10; i ++)
	{
		if(Sg[i] == 0)
		{
			break;
		}
		if((i == 9) && (Sg[9] == 1))
		{
			printf("The Single List lib is full,create List fail\n");
			return ERROR;
		}
	}

	Sg[i] = 1;
	SgListlib[i].List.Type = SgLinkedlist;

//get name	
	printf("Name(under 10 char):");

	while(1)
	{
		scanf("%s", name);
		if(!((strlen(name) > 10) || (IfOccupy(name))))
		{
			break;
		}
		printf("It is illegal!\n");
		printf("Name(under 10 char):");
	}
	strcpy(SgListlib[i].List.name, name);

//get data
	printf("Enter the data control + z to end\n");
	scanf("%d", &data);

	InitList(&(SgListlib[i].HeadNode));
	temp1 = SgListlib[i].HeadNode;
	temp1->data = data;

	while(scanf("%d", &data) != EOF)
	{
		InitList(&temp2);
		temp2->data = data;
		temp1->next = temp2;
		temp1 = temp1->next;
	}

	printf("OK\n");
	return SUCCESS;
}

Status CreateDbList()
{
	int i;
	char name[100];
	ElemType data;
	DuLinkedList Head = NULL;
	DuLinkedList temp1, temp2 = NULL;

	for(i = 0; i < 10; i ++)
	{
		if(Db[i] == 0)
		{
			break;
		}
		if((i == 9) && (Sg[9] == 1))
		{
			printf("The DuList lib is full,create List fail\n");
			return ERROR;
		}
	}

	Db[i] = 1;
	DbListlib[i].List.Type = DbLinkedlist;

//get name	
	printf("Name(under 10 char):");
	
	while(1)
	{
		scanf("%s", name);
		if(!((strlen(name) > 10) || (IfOccupy(name))))
		{
			break;
		}
		printf("It is illegal!\n");
		printf("Name(under 10 char):");
	}
	strcpy(DbListlib[i].List.name, name);

//get data
	printf("Enter the data control + z to end\n");
	scanf("%d", &data);

	InitList_DuL(&(DbListlib[i].HeadNode));
	temp1 = DbListlib[i].HeadNode;
	temp1->data = data;

	while(scanf("%d", &data) != EOF)
	{
		InitList_DuL(&temp2);
		temp2->data = data;
		temp1->next = temp2;
		temp2->prior = temp1;
		temp1 = temp1->next;
	}
	printf("OK\n");
	return SUCCESS;
}

void DisplayList()
{
	int i;

	printf("Single Linked List are following:\n");
	for(i = 0; i < 10; i ++)
	{
		if(Sg[i])
		{
			printf("%s\n", SgListlib[i].List.name);
			TraverseList(SgListlib[i].HeadNode, PrintData);
		}
	}
	printf("DuLinked List are following:\n");
	for(i = 0; i < 10; i ++)
	{
		if(Db[i])
		{
			printf("%s\n", DbListlib[i].List.name);
			TraverseList_DuL(DbListlib[i].HeadNode, PrintData);
		}
	}
}

void CreateList()
{
	int judge = 1;
	int num = 0;

	while(judge)
	{
		printf("Type(1.Single/2.DuList):");
		scanf("%d", &num);
		switch (num)
		{
		case 1:
			CreateSgList();
			judge = 0;
			break;
		case 2:
			CreateDbList();
			judge = 0;
			break;
		}
	}
}

void Destory(char name[11])
{
	int i;

	for(i = 0; i < 10; i ++)
	{
		if((Db[i]) && (strcmp(DbListlib[i].List.name, name) == 0))
		{
			Db[i] = 0;
			DestroyList_DuL(&DbListlib[i].HeadNode);
			break;
		}
		if((Sg[i]) && (strcmp(SgListlib[i].List.name, name) == 0))
		{
			DestroyList(&(SgListlib[i].HeadNode));
			Sg[i] = 0;
			break;
		}
	}
}

void Reverse(char name[11])
{
	int i;

	for(i = 0; i < 10; i ++)
	{
		if((Sg[i]) && (strcmp(SgListlib[i].List.name, name) == 0))
		{
			ReverseList(&(SgListlib[i].HeadNode));
			break;
		}
		if((Db[i]) && (strcmp(DbListlib[i].List.name, name) == 0))
		{
			printf("Sorry, this function only use for single List\n");
			break;
		}
	}
}

void Find(char name[11])
{
	int i;
	LinkedList temp;

	for(i = 0; i < 10; i ++)
	{
		if((Sg[i]) && (strcmp(SgListlib[i].List.name, name) == 0))
		{
			temp = FindMidNode(&(SgListlib[i].HeadNode));
			printf("The mid data is %d\n",temp->data);
			break;
		}
		if((Db[i]) && (strcmp(DbListlib[i].List.name, name) == 0))
		{
			printf("Sorry, this function only use for single List\n");
			break;
		}
	}
}

void DeleteNode(char name[11])
{
	int i;
	LinkedList Stemp;


	for(i = 0; i < 10; i ++)
	{
		if((Sg[i]) && (strcmp(SgListlib[i].List.name, name) == 0))
		{
			Stemp = ReverseEvenList(&(SgListlib[i].HeadNode));
			break;
		}
		if((Db[i]) && (strcmp(DbListlib[i].List.name, name) == 0))
		{
			
			break;
		}
	}
}

func fun_arry[4] = {NULL, Destory, Reverse, Find};

Status MotiFun(void (*fun)(char name[11]))
{			
	char name[100];

	printf("Choose a List:\n");	
	printf("(enter its name)\n");
	scanf("%s", name);

	if(!IfOccupy(name))
	{
		printf("It is inexist\n");
		printf("Here is name of the List\n");
		DisplayList();
		return ERROR;
	}
	fun(name);
	printf("OK\n");
	return SUCCESS;
}

void OperateList()
{
	int SeleN;
	int Doing = 1;

	while(Doing)
	{
		printf("/************************************\\\n");
		printf("1.Destory List\n");
		printf("2.ReverseList\n");
		printf("3.Find mid Node\n");
		printf("9.back\n");
		printf("Please enter 1/2/3/9\n");
		printf("\\************************************/\n");
		scanf("%d", &SeleN);
		fflush(stdin);
		switch (SeleN)
		{
		case 1:
		case 2:
		case 3:
			MotiFun(fun_arry[SeleN]);
			break;
		case 9:
			Doing = 0;
			break;
		}
	}

}

int main()
{
	int SeleN;
	while(1)
	{
		printf("/************************************\\\n");
		printf("1.Show all List\n");
		printf("2.Create a List\n");
		printf("3.Change a List\n");
		printf("Please enter 1/2/3\n");
		printf("\\************************************/\n");
		scanf("%d", &SeleN);
		fflush(stdin);
		switch (SeleN)
		{
		case 1:
			DisplayList();
			break;
		case 2:
			CreateList();
			break;
		case 3:
			OperateList();
			break;
		}
	}

	system("pause");
	return 0;
}


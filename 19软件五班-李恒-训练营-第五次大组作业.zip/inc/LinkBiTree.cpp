/***************************************************************************************
 *    File Name                :    AQueue.h
 *    CopyRight                :
 *
 *    SYSTEM                   :   win7
 *    Create Data              :    2020.4.26
 *    Author/Corportation      :  lh
 *
 *
 *--------------------------------Revision History--------------------------------------
 *    No    version        Data            Revised By            Item            Description
 *
 *
 ***************************************************************************************/


#include"LinkBiTree.h"

char *str;
BiTree NewNode;
QueueNode *NewQNode;
LQueue *Queue;

void gotoxy(int x, int y)
{
    COORD pos = {x,y};
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);// ��ȡ��׼����豸���
    SetConsoleCursorPosition(hOut, pos);          //���������ֱ���ָ���ĸ����壬����λ��
} 

int GetNum()
{
	char data[5];
	int i;

	printf("  ");
	scanf_s("%s", data, 4);
	fflush(stdin);

	if(strlen(data) >= 4)
	{
		printf("  �Ƿ�����\n");
		return GetNum();
	}
	for(i = 0; (i < 9) && (data[i] != '\0'); i ++)
	{
		if(('0' > data[i]) || (data[i] > '9'))
		{
			printf("  �Ƿ�����\n");
			return GetNum();                 //�ظ����ң�����ҵ��˾ͷ�����ȷ��ֵ
		}
	}
	return atoi(data);
}

void InitQueue()
{
	NewQNode = (QueueNode *)malloc(sizeof(QueueNode));
	NewQNode->data = NULL;
	Queue = (LQueue *)malloc(sizeof(LQueue));
	Queue->front = NewQNode;
	Queue->rear = NewQNode;
}

void EnQueue(BiTree rear)
{
	if(Queue->front->data == NULL)
	{
		Queue->front->data = rear;
		return ;
	}
	NewQNode = (QueueNode *)malloc(sizeof(QueueNode));
	NewQNode->data = rear;
	NewQNode->next = NULL;
	Queue->rear->next = NewQNode;
	Queue->rear = NewQNode;
}

BiTree DeQueue()
{
	BiTree des;
	QueueNode *temp;
	if(Queue->front->data == NULL)
	{
		return NULL;
	}
	else if(Queue->front == Queue->rear)
	{
		temp = Queue->front;
		des = temp->data;
		Queue->front->data = NULL;
		return des;
	}
	else
	{
		temp = Queue->front;
		des = temp->data;
		Queue->front = temp->next;
		free(temp);
		return des;
	}
}

Status InitBiTree(BiTree *T)
{
	if(*T == NULL)
	{
		*T = (BiTree)malloc(sizeof(BiTNode));
	}
	(*T)->lchild = NULL;
	(*T)->rchild = NULL;
	(*T)->data = '0';
	return _SUCCESS;
}

Status DestroyBiTree(BiTree T)
{
	if(T->lchild != NULL)
	{
		DestroyBiTree(T->lchild);
	}
	else if(T->rchild != NULL)
	{
		DestroyBiTree(T->rchild);
	}
	free(T);
	T = NULL;
	return _SUCCESS;
}

Status CreateBiTree(BiTree T, char* definition)
{
	NewNode = NULL;

	str = definition;
	T->data = *str;               //����ֵ

	if(isopt(str[0]))             //����ǲ���������������
	{
		str ++;                   //����������
		InitBiTree(&NewNode);
		T->lchild = NewNode;
		CreateBiTree(NewNode, str);
		
		str ++;                   //����������
		InitBiTree(&NewNode);
		T->rchild = NewNode;
		CreateBiTree(NewNode, str);
		return _SUCCESS;
	}
	else                          //������ǲ������������֣�ֱ�ӷ���
	{
		return _SUCCESS;
	}
}

Status PreOrderTraverse(BiTree T, Status (*visit)(TElemType e))
{
	if(T == NULL)
	{
		return _ERROR;
	}
	visit(T->data);
	if(T->lchild != NULL)
	{
		PreOrderTraverse(T->lchild, visit);
	}
	if(T->rchild != NULL)
	{
		PreOrderTraverse(T->rchild, visit);
	}
	return _SUCCESS;
}

Status InOrderTraverse(BiTree T, Status (*visit)(TElemType e))
{
	if(T == NULL)
	{
		return _ERROR;
	}
	if(T->lchild != NULL)
	{
		InOrderTraverse(T->lchild, visit);
	}
	visit(T->data);
	if(T->rchild != NULL)
	{
		InOrderTraverse(T->rchild, visit);
	}
	return _SUCCESS;
}

Status PostOrderTraverse(BiTree T, Status (*visit)(TElemType e))
{
	if(T == NULL)
	{
		return _ERROR;
	}
	if(T->lchild != NULL)
	{
		PostOrderTraverse(T->lchild, visit);
	}
	if(T->rchild != NULL)
	{
		PostOrderTraverse(T->rchild, visit);
	}
	visit(T->data);
	return _SUCCESS;
}

Status LevelOrderTraverse(BiTree T, Status (*visit)(TElemType e))
{
	BiTree temp;
	if(T == NULL)
	{
		return _ERROR;
	}
	EnQueue(T);
	while(Queue->front->data != NULL)     //ջΪ�ս���
	{
		temp = DeQueue();
		visit(temp->data);
		if(temp->lchild != NULL)
		{
			EnQueue(temp->lchild);
		}
		if(temp->rchild != NULL)
		{
			EnQueue(temp->rchild);
		}
	}
	return _SUCCESS;
}

int calculate(BiTree T)
{
	int ans;

	if(isopt(T->data))
	{
		if(T->data == '+')
		{
			ans = calculate(T->lchild) + calculate(T->rchild);
		}
		if(T->data == '-')
		{
			ans = calculate(T->lchild) - calculate(T->rchild);
		}
		if(T->data == '*')
		{
			ans = calculate(T->lchild) * calculate(T->rchild);
		}
		if(T->data == '/')
		{
			ans = calculate(T->lchild) / calculate(T->rchild);
		}
	}
	else
	{
		return (T->data - '0');
	}
	return ans;
}

Status Print(TElemType data)
{
	printf("%c", data);
	return _SUCCESS;
}


int main()
{
	system("mode con cols=42 lines=30");
	system("color f7");
	char ca[50];
	BiTree T;
	T = NULL;
	bool end;

	end = 0;
	do
	{
		system("CLS");
		HANDLE hdl = GetStdHandle(STD_OUTPUT_HANDLE);

		gotoxy(2, 4);
		SetConsoleTextAttribute(hdl, FOR_INI_BLUE|SET_WHITE);
		printf("/********ǰ׺����ʽ����������********\\\n");
		SetConsoleTextAttribute(hdl, FOR_INI_RED|SET_WHITE);
		printf("  |*****1.��ʼ��                  *****|\n");
		printf("  |*****2.������                  *****|\n");
		printf("  |*****3.������                  *****|\n");
		printf("  |*****4.���                    *****|\n");
		printf("  |*****5.������                *****|\n");
		printf("  |*****6.�˳�                    *****|\n");
		SetConsoleTextAttribute(hdl, FOR_INI_BLUE|SET_WHITE);
		printf("  \\************************************/\n");   //38�ַ�

		printf("  ���ѡ���ǣ�");
		switch(GetNum())
		{
		case 1:
			if(T != NULL)
			{
				printf("  ���Ѿ�����");
				break;
			}
			InitBiTree(&T);
			printf("  �ɹ�����\n");
			break;
		case 2:
			if(T == NULL)
			{
				printf("  ���ȳ�ʼ��");
				break;
			}
			if(T->data != '0')
			{
				printf("  ����������");
				break;
			}
			printf("  ������ǰ׺����ʽ��\n");
			do
			{
				printf("  ");
				scanf_s("%s", ca, 50);
				fflush(stdin);
				CreateBiTree(T, ca);
				if(str == &ca[strlen(ca) - 1])
				{
					break;
				}
				printf("  ������ǰ׺����ʽ\n  ����������\n");
			}while(1);
			printf("  �õ�\n");
			break;
		case 3:
			if(T == NULL)
			{
				printf("  ��������");
				break;
			}
			DestroyBiTree(T);
			T = NULL;
			printf("  �õ�\n");
			break;		
		case 4:
			if(T == NULL)
			{
				printf("  ��������");
				break;
			}
			printf("  �����������ʽ��\n  ");
			PreOrderTraverse(T, Print);
			printf("\n");
			printf("  �����������ʽ��\n  ");
			InOrderTraverse(T, Print);
			printf("\n");
			printf("  �����������ʽ��\n  ");
			PostOrderTraverse(T, Print);
			printf("\n");
			InitQueue();
			printf("  �����������ʽ��\n  ");
			LevelOrderTraverse(T, Print);
			printf("\n");
			break;
		case 5:
			if(T == NULL)
			{
				printf("  ��������");
				break;
			}
			printf("  ��������  %d\n", calculate(T));
			break;
		case 6:
			end = 1;
			break;
		default:
			printf("  û�����ѡ��");
		}
		getchar();
	}while(!end);
}
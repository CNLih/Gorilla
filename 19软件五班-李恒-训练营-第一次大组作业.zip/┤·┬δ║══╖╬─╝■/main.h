/***************************************************************************************
 *	File Name				:	main.h
 *	CopyRight				:	lih
 *	SYSTEM					:   win7
 *	Create Data				:	2020.4.2
 *
 *
 *--------------------------------Revision History--------------------------------------
 *	No	version		Data			Revised By			Item			Description
 *
 *
 ***************************************************************************************/

 /**************************************************************
*	Multi-Include-Prevent Section
**************************************************************/
#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

/**************************************************************
*	Includes Section
**************************************************************/

#include<stdio.h>
#include<stdlib.h>
#include <string.h>

#include "../head/linkedList.h"
#include "../head/duLinkedList.h"

typedef void (*func) (char name[11]);

/**
 *  @name        : Status IfOccupy(char name[11]);
 *	@description : if there is same name
 *	@param		 : name of the list
 *	@return		 : Status
 *  @notice      : 
 */
Status IfOccupy(char name[11]);

/**
 *  @name        : Status CreateSgList();
 *	@description : create a single list
 *	@param		 : 
 *	@return		 : Status
 *  @notice      : 
 */
Status CreateSgList();

/**
 *  @name        : Status CreateDbList();
 *	@description : create a two way list
 *	@param		 : 
 *	@return		 : Status
 *  @notice      : 
 */
Status CreateDbList();

/**
 *  @name        : void DisplayList();
 *	@description : display all list 
 *	@param		 : 
 *	@return		 : 
 *  @notice      : 
 */
void DisplayList();

/**
 *  @name        : void CreateList();
 *	@description : create a list 
 *	@param		 : 
 *	@return		 : 
 *  @notice      : 
 */
void CreateList();

/**
 *  @name        : void Destory(char name[11]);
 *	@description : destory list
 *	@param		 : list name
 *	@return		 : 
 *  @notice      : 
 */
void Destory(char name[11]);

/**
 *  @name        : void Reverse(char name[11]);
 *	@description : reverse list
 *	@param		 : list name
 *	@return		 : 
 *  @notice      : 
 */
void Reverse(char name[11]);




#endif

/***************************************************************************************
 *    File Name                :    AQueue.cpp
 *    CopyRight                :
 *
 *    SYSTEM                    :   win7
 *    Create Data                :    2020.4.11
 *    Author/Corportation        :   lih
 *
 *
 *--------------------------------Revision History--------------------------------------
 *    No    version        Data            Revised By            Item            Description
 *
 *
 ***************************************************************************************/

/**************************************************************
 *    Multi-Include-Prevent Section
 **************************************************************/
#ifndef AQUEUE_CPP
#define AQUEUE_CPP

/**************************************************************
 *    Include Section
 **************************************************************/
#include "AQueue.h"

/**
 *  @name        : void InitAQueue(AQueue *Q)
 *    @description : ��ʼ������
 *    @param         Q ����ָ��Q
 *  @notice      : None
 */
void InitAQueue(AQueue *Q)
{
	*Q->data = (void *)malloc(10 * sizeof(void *));

	Q->front = 0;
	Q->rear = 0;
	Q->length = 0;

	printf("OK\n");
}


/**
 *  @name        : void DestoryAQueue(AQueue *Q)
 *    @description : ���ٶ���
 *    @param         Q ����ָ��Q
 *  @notice      : None
 */
void DestoryAQueue(AQueue *Q)
{
	free(*(Q->data));
	*(Q->data) = NULL;
}


/**
 *  @name        : Status IsFullAQueue(const AQueue *Q)
 *    @description : �������Ƿ�����
 *    @param         Q ����ָ��Q
 *    @return         : ��-TRUE; δ��-FALSE
 *  @notice      : None
 */
Status IsFullAQueue(const AQueue *Q)
{
	if(Q->length == MAXQUEUE)
	{
		return _TRUE;
	}
	else
	{
		return _FALSE;
	}
}


/**
 *  @name        : Status IsEmptyAQueue(const AQueue *Q)
 *    @description : �������Ƿ�Ϊ��
 *    @param         Q ����ָ��Q
 *    @return         : ��-TRUE; δ��-FALSE
 *  @notice      : None
 */
Status IsEmptyAQueue(const AQueue *Q)
{
	if(Q->length == 0)
	{
		return _TRUE;
	}
	else
	{
		return _FALSE;
	}
}


/**
 *  @name        : Status GetHeadAQueue(AQueue *Q, void *e)
 *    @description : �鿴��ͷԪ��
 *    @param         Q ����ָ��Q�����Ԫ��e
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : �����Ƿ��
 */
Status GetHeadAQueue(AQueue *Q, void **e)
{
	if(IsEmptyAQueue(Q))
	{
		return _FALSE;
	}
	*e = Q->data[Q->front];

	return _TRUE;
}


/**
 *  @name        : int LengthAQueue(AQueue *Q)
 *    @description : ȷ�����г���
 *    @param         Q ����ָ��Q
 *    @return         : ���г���count
 *  @notice      : None
 */
int LengthAQueue(AQueue *Q)
{
	return Q->length;
}


/**
 *  @name        : Status EnAQueue(AQueue *Q, void *data)
 *    @description : ��Ӳ���
 *    @param         Q ����ָ��Q,�������ָ��data
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : �����Ƿ����˻�Ϊ��
 */
Status EnAQueue(AQueue *Q, void *data)
{
	if(IsEmptyAQueue(Q))
	{
		Q->data[0] = data;
		Q->length ++;
		return _TRUE;
	}
	if(IsFullAQueue(Q))
	{
		return _FALSE;
	}
	Q->length ++;
	Q->rear = (Q->rear + 1) % MAXQUEUE;
	Q->data[Q->rear] = data;

	return _TRUE;
}


/**
 *  @name        : Status DeAQueue(AQueue *Q)
 *    @description : ���Ӳ���
 *    @param         Q ����ָ��Q
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : None
 */
Status DeAQueue(AQueue *Q)
{
	if(IsEmptyAQueue(Q))
	{
		return _FALSE;
	}
	Q->length --;
	Q->data[Q->front] = 0;
	if(Q->length == 0)
	{
		return _TRUE;
	}
	Q->front = (Q->front + 1) % MAXQUEUE;

	return _TRUE;
}


/**
 *  @name        : void ClearAQueue(Queue *Q)
 *    @description : ��ն���
 *    @param         Q ����ָ��Q
 *  @notice      : None
 */
void ClearAQueue(AQueue *Q)
{
	Q->front = 0;
	Q->rear = 0;
	Q->length = 0;
}


/**
 *  @name        : Status TraverseAQueue(const AQueue *Q, void (*foo)(void *q))
 *    @description : ������������
 *    @param         Q ����ָ��Q����������ָ��foo
 *    @return         : None
 *  @notice      : None
 */
Status TraverseAQueue(const AQueue *Q, void (*foo)(void *q))
{
	unsigned i;

	for(i = 0; i < (Q->length); i ++)
	{
		foo(Q->data[i + Q->front]);
	}

	return _TRUE;
}


/**
 *  @name        : void APrint(void *q)
 *    @description : ��������
 *    @param         q ָ��q
 *  @notice      : None
 */
void APrint(void *q)
{
	if(strcmp(datatype, "int") == 0)
	{
		printf("%d  ", *(int *)q);
	}
	if(strcmp(datatype, "char") == 0)
	{
		printf("%c  ", *(char *)q);
	}
	if(strcmp(datatype, "string") == 0)
	{
		printf("%s  ", (char *)q);
	}
	if(strcmp(datatype, "float") == 0)
	{
		printf("%f  ", *(float *)q);
	}
}


/**
 *  @name        : void *GetData()
 *    @description : ��ȡ����
 *    @param         
 *  @notice      : None
 */
void *GetData()
{
	void *data = NULL;

	if(strcmp(datatype, "int") == 0)
	{
		data = (int *)malloc(sizeof(int));
		scanf("%d", data);
	}
	if(strcmp(datatype, "char") == 0)
	{
		data = (char *)malloc(sizeof(char));
		scanf("%c", data);
	}
	if(strcmp(datatype, "string") == 0)
	{
		data = (char *)malloc(100 * sizeof(int));
		scanf("%s", data);
	}
	if(strcmp(datatype, "float") == 0)
	{
		data = (char *)malloc(sizeof(float));
		scanf("%f", data);
	}
	return data;
}


/**
 *  @name        : void *GetNum()
 *    @description : ��ȡ�Ϸ�����������
 *    @param         
 *  @notice      : None
 */
int GetNum()
{
	char data[100];
	int i;

	scanf_s("%s", data, 50);
	fflush(stdin);

	if(strlen(data) >= 10)
	{
		printf("You can only store up to 999999999 try again\n");
		return GetNum();
	}
	for(i = 0; (i < 9) && (data[i] != '\0'); i ++)
	{
		if(('0' > data[i]) || (data[i] > '9'))
		{
			printf("Your enter is illegal, Try again\n");
			return GetNum();                 //�ظ����ң�����ҵ��˾ͷ�����ȷ��ֵ
		}
	}
	return atoi(data);
}


/**
 *  @name        : void ChooseType()
 *    @description : ѡ����������
 *    @param         
 *  @notice      : None
 */
void ChooseType()
{
	system("CLS");
	HANDLE hdl = GetStdHandle(STD_OUTPUT_HANDLE);

	SetConsoleTextAttribute(hdl, FOR_INI_BLUE|SET_WHITE);
	printf("/*********���еĻ�������*********\\\n");
	printf("|****��ѡ�������ŵ���������****|\n");
	SetConsoleTextAttribute(hdl, FOR_INI_RED|SET_WHITE);
	printf("|****1.int                   ****|\n");
	printf("|****2.char                  ****|\n");
	printf("|****3.float                 ****|\n");
	printf("|****4.string                ****|\n");
	SetConsoleTextAttribute(hdl, FOR_INI_BLUE|SET_WHITE);
	printf("\\********************************/\n");
	switch(GetNum())
	{
	case 1:
		strcpy(datatype, "int");
		break;
	case 2:
		strcpy(datatype, "char");
		break;
	case 3:
		strcpy(datatype, "float");
		break;
	case 4:
		strcpy(datatype, "string");
		break;
	default:
		ChooseType();
	}
}


int main()
{
	AQueue que;
	*(que.data) = NULL;
	int choice;
	void *data = NULL;
	HANDLE hdl = GetStdHandle(STD_OUTPUT_HANDLE);
	int flag = 0;
	system("color f7");

	ChooseType();

	while(1)
	{
		system("CLS");
		SetConsoleTextAttribute(hdl, FOR_INI_BLUE|SET_WHITE);
		printf("/*********���еĻ�������*********\\\n");
		SetConsoleTextAttribute(hdl, FOR_INI_RED|SET_WHITE);
		printf("|****1.InitAQueue            ****|\n");
		printf("|****2.DestoryAQueue         ****|\n");
		printf("|****3.IsFullAQueue          ****|\n");
		printf("|****4.IsEmptyAQueue         ****|\n");
		printf("|****5.GetHeadAQueue         ****|\n");
		printf("|****6.LengthAQueue          ****|\n");
		printf("|****7.EnAQueue              ****|\n");
		printf("|****8.DeAQueue              ****|\n");
		printf("|****9.ClearAQueue           ****|\n");
		printf("|****10.PrintQueue           ****|\n");
		printf("|****11.ChangeType           ****|\n");
		SetConsoleTextAttribute(hdl, FOR_INI_BLUE|SET_WHITE);
		printf("\\********************************/\n");

		choice = GetNum();
		switch(choice)
		{
		SetConsoleTextAttribute(hdl, FOR_INI_RED|SET_WHITE);
		case 1:
			InitAQueue(&que);
			flag = 1;
			printf("Press any key to continue\n");
			break;
		case 2:
			if(flag)
			{
				DestoryAQueue(&que);
				flag = 0;
				printf("OK!\nPress any key to continue\n");
			}
			else
			{
				printf("ERROR:The queue haven't init\n");
			}
			break;
		case 3:
			if(!flag)
			{
				printf("ERROR:The queue haven't init\n");
				break;
			}
			if(IsFullAQueue(&que))
			{
				printf("The queue is full\n");
			}
			else
			{
				printf("The queue isn't full\n");
			}
			break;
		case 4:
			if(!flag)
			{
				printf("ERROR:The queue haven't init\n");
				break;
			}
			if(IsEmptyAQueue(&que))
			{
				printf("The queue is empyt\n");
			}
			else
			{
				printf("The queue isn't empyt\n");
			}
			break;
		case 5:
			if(!flag)
			{
				printf("ERROR:The queue haven't init\n");
				break;
			}
			if(!IsEmptyAQueue(&que))
			{
				printf("The head of the queue is \n");
				GetHeadAQueue(&que, &data);
				APrint(data);
			}
			else
			{
				printf("The queue is empty\n");
			}
			break;
		case 6:
			if(!flag)
			{
				printf("ERROR:The queue haven't init\n");
				break;
			}
			printf("The queue length is %d\n", LengthAQueue(&que));
			break;
		case 7:
			if(!flag)
			{
				printf("ERROR:The queue haven't init\n");
				break;
			}
			if(!IsFullAQueue(&que))
			{
				printf("Enter your data:\n");
				EnAQueue(&que, GetData());
			}
			break;
		case 8:
			if(!flag)
			{
				printf("ERROR:The queue haven't init\n");
				break;
			}
			DeAQueue(&que);
			printf("OK");
			break;
		case 9:
			if(!flag)
			{
				printf("ERROR:The queue haven't init\n");
				break;
			}
			ClearAQueue(&que);
			break;
		case 10:
			if(!flag)
			{
				printf("ERROR:The queue haven't init\n");
				break;
			}
			if(IsEmptyAQueue(&que))
			{
				printf("The queue is empyt\n");
			}
			TraverseAQueue(&que, APrint);
			break;
		case 11:
			if(flag)
			{
				printf("You should destory current queue\n");
			}
			else
			{
				ChooseType();
			}
			break;
		default:
			printf("No this choice\n");
		}
		getchar();
		fflush(stdin);
	}

	CloseHandle(hdl);
}


#endif
#include "../head/duLinkedList.h"

/**
 *  @name        : Status InitList_DuL(DuLinkedList *L)
 *	@description : initialize an empty linked list with only the head node
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList_DuL(DuLinkedList *L) {
	*L = (DuLinkedList)malloc(sizeof(DuLNode));

	if(*L == NULL)
	{
		printf("Create node fail, try again\n");
		return ERROR;
	}
	else
	{
		(*L)->prior = NULL;
		(*L)->next = NULL;
		return SUCCESS;
	}
}

/**
 *  @name        : void DestroyList_DuL(DuLinkedList *L)
 *	@description : destroy a linked list
 *	@param		 : L(the head node)
 *	@return		 : status
 *  @notice      : None
 */
void DestroyList_DuL(DuLinkedList *L) {
	DuLinkedList P1, P2;
	P1 = *L;

	for(; P1 != NULL;)
	{
		P2 = P1->next;
		free(P1);
		P1 = P2;
	}
	*L = NULL;
}

/**
 *  @name        : Status InsertBeforeList_DuL(DuLNode *p, LNode *q)
 *	@description : insert node q before node p
 *	@param		 : p, q
 *	@return		 : status
 *  @notice      : None
 */
Status InsertBeforeList_DuL(DuLNode *p, DuLNode *q) {
	if((p == NULL) || (q == NULL))
	{
		return ERROR;
	}
	if(p->prior != NULL)
	{
		q->prior = p->prior;
	}
	p->prior = q;
	q->next = p;
	return SUCCESS;
}

/**
 *  @name        : Status InsertAfterList_DuL(DuLNode *p, DuLNode *q)
 *	@description : insert node q after node p
 *	@param		 : p, q
 *	@return		 : status
 *  @notice      : None
 */
Status InsertAfterList_DuL(DuLNode *p, DuLNode *q) {
	if((p == NULL) || (q == NULL))
	{
		return ERROR;
	}
	if(p->next != NULL)
	{
		q->next = p->next;
	}
	p->next = q;
	q->prior = p;
	return SUCCESS;
}

/**
 *  @name        : Status DeleteList_DuL(DuLNode *p, ElemType *e)
 *	@description : delete the first node after the node p and assign its value to e
 *	@param		 : p, e
 *	@return		 : status
 *  @notice      : None
 */
Status DeleteList_DuL(DuLNode *p, ElemType *e) {
	DuLinkedList temp;
	
	temp = p->next;

	if(temp = NULL)
	{
		printf("This is the final node\n");
		return ERROR;
	}

	*e = temp->data;
	p->next = temp->next;
	free(temp);
	return SUCCESS;
}

/**
 *  @name        : void TraverseList_DuL(DuLinkedList L, void (*visit)(ElemType e))
 *	@description : traverse the linked list and call the funtion visit
 *	@param		 : L(the head node), visit
 *	@return		 : Status
 *  @notice      : None
 */
void TraverseList_DuL(DuLinkedList L, void (*visit)(ElemType e)) {
	DuLinkedList temp;

	for(temp = L; temp != NULL; temp = temp->next)
	{
		visit(temp->data);
	}
	printf("\n");
}

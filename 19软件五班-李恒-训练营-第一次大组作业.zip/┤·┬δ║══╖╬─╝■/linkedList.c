#include "../head/linkedList.h"

/**
 *  @name        : Status InitList(LinkList *L);
 *	@description : initialize an empty linked list with only the head node without value
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList(LinkedList *L) {
	*L = (LinkedList)malloc(sizeof(LNode));

	if(*L == NULL)
	{
		printf("Create node fail, try again\n");
		return ERROR;
	}
	else
	{
		(*L)->next = NULL;
		return SUCCESS;
	}
}

/**
 *  @name        : void DestroyList(LinkedList *L)
 *	@description : destroy a linked list, free all the nodes
 *	@param		 : L(the head node)
 *	@return		 : None
 *  @notice      : None
 */
void DestroyList(LinkedList *L) {
	LinkedList P1, P2;
	P1 = *L;

	for(; P1 != NULL;)
	{
		P2 = P1->next;
		free(P1);
		P1 = P2;
	}
	*L = NULL;
}

/**
 *  @name        : Status InsertList(LNode *p, LNode *q)
 *	@description : insert node q after node p
 *	@param		 : p, q
 *	@return		 : Status
 *  @notice      : None
 */
Status InsertList(LNode *p, LNode *q) {
	if((p == NULL) || (q == NULL))
	{
		return ERROR;
	}
	p->next = q;
}
/**
 *  @name        : Status DeleteList(LNode *p, ElemType *e)
 *	@description : delete the first node after the node p and assign its value to e
 *	@param		 : p, e
 *	@return		 : Status
 *  @notice      : None
 */
Status DeleteList(LNode *p, ElemType *e) {
	LNode *temp;
	
	temp = p->next;

	if(temp = NULL)
	{
		printf("This is the final node\n");
		return ERROR;
	}

	*e = temp->data;
	p->next = temp->next;
	free(temp);
	return SUCCESS;
}

/**
 *  @name        : void TraverseList(LinkedList L, void (*visit)(ElemType e))
 *	@description : traverse the linked list and call the funtion visit
 *	@param		 : L(the head node), visit
 *	@return		 : None
 *  @notice      : None
 */
void TraverseList(LinkedList L, void (*visit)(ElemType e)) {
	LinkedList temp;

	for(temp = L; temp != NULL; temp = temp->next)
	{
		visit(temp->data);
	}
	printf("\n");
}

/**
 *  @name        : Status SearchList(LinkedList L, ElemType e)
 *	@description : find the first node in the linked list according to e
 *	@param		 : L(the head node), e
 *	@return		 : Status
 *  @notice      : None
 */
Status SearchList(LinkedList L, ElemType e) {
	LinkedList temp, head;
	char YorN;
	int lengh = 100;

	head = L;
	if(!IsLoopList(L))
	{
		for(temp = L; temp != NULL; temp = temp->next)
		{
			if(temp->data == e)
			{
				return SUCCESS;
			}
		}
	}
	else
	{
		printf("Sorry this function use for LoopList is incomplete.\n");
		printf("Do you still want to search?(Y/N)\n");
		do
		{
			YorN = getchar();
			if(YorN == 'y' || YorN == 'Y')
			{
				while(lengh --)
				{
					for(temp = L; temp != NULL; temp = temp->next)
					{
						if(temp->data == e)
						{
						return SUCCESS;
						}
					}
				}
				return ERROR;
			}
			if(YorN == 'n' || YorN == 'N')
			{
				return ERROR;
			}
		}while(1);
	}
}

/**
 *  @name        : Status ReverseList(LinkedList *L)
 *	@description : reverse the linked list
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status ReverseList(LinkedList *L) {
	LinkedList NewHead, temp1, temp2;

	for(temp1 = *L; temp1->next != NULL; temp1 = temp2->next)
	{
		temp2 = temp1;
	}
	NewHead = temp1;
	for(; temp2 != *L; )
	{
		for(temp2 = *L; temp2->next != temp1; temp2 = temp2->next)
		{
			;
		}
		InsertList(temp1, temp2);
		temp1 = temp2;
	}
	(*L)->next = NULL;
	(*L) = NewHead;

}

/**
 *  @name        : Status IsLoopList(LinkedList L)
 *	@description : judge whether the linked list is looped
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status IsLoopList(LinkedList L) {
	LinkedList fast, slow;
	fast = slow = L;

	for(; fast != NULL; )
	{
		if(fast->next == NULL)
		{
			return ERROR;
		}
		else if(fast->next == NULL)
		{
			return ERROR;
		}
		fast = fast->next->next;
		slow = slow->next;
		if(fast == slow)
		{
			return SUCCESS;
		}
	}
}

/**
 *  @name        : LNode* ReverseEvenList(LinkedList *L)
 *	@description : reverse the nodes which value is an even number in the linked list, input: 1 -> 2 -> 3 -> 4  output: 2 -> 1 -> 4 -> 3
 *	@param		 : L(the head node)
 *	@return		 : LNode(the new head node)
 *  @notice      : choose to finish
 */
LNode* ReverseEvenList(LinkedList *L) {

}

/**
 *  @name        : LNode* FindMidNode(LinkedList *L)
 *	@description : find the middle node in the linked list
 *	@param		 : L(the head node)
 *	@return		 : LNode
 *  @notice      : choose to finish
 */
LNode* FindMidNode(LinkedList *L) {
	LinkedList fast, slow;

	if(IsLoopList(*L))
	{
		printf("Sorry, this function cant use in looplist\n");
	}

	for(fast = slow = *L; fast != NULL; fast = fast->next)
	{
		if(fast->next == NULL)
		{
			return slow;
		}
		fast = fast->next;
		slow = slow->next;
	}
	printf("The amount of the list is an even, "
		"its has two mid node,here is the second node\n");
	return slow;
}


/***************************************************************************************
 *    File Name                :    AQueue.cpp
 *    CopyRight                :
 *
 *    SYSTEM                    :   win7
 *    Create Data                :    2020.4.11
 *    Author/Corportation        :   lih
 *
 *
 *--------------------------------Revision History--------------------------------------
 *    No    version        Data            Revised By            Item            Description
 *
 *
 ***************************************************************************************/

/**************************************************************
 *    Multi-Include-Prevent Section
 **************************************************************/
#ifndef LQUEUE_CPP
#define LQUEUE_CPP

/**************************************************************
 *    Include Section
 **************************************************************/
#include "LQueue.h"


/**
 *  @name        : void InitLQueue(LQueue *Q)
 *    @description : ��ʼ������
 *    @param         Q ����ָ��Q
 *  @notice      : None
 */
void InitLQueue(LQueue *Q)
{
	Q->front = NULL;
	Q->rear = NULL;
	Q->length = 0;
	top = -1;
	rear = 0;
}


/**
 *  @name        : void DestoryLQueue(LQueue *Q)
 *    @description : ���ٶ���
 *    @param         Q ����ָ��Q
 *  @notice      : None
 */
void DestoryLQueue(LQueue *Q)
{
	Node *nod, *temp;
	for(nod = Q->front; nod != NULL; )
	{
		temp = nod;
		nod = nod->next;
		free(temp);
	}
	InitLQueue(Q);
	top = -1;
	rear = 0;
}


/**
 *  @name        : Status IsEmptyLQueue(const LQueue *Q)
 *    @description : �������Ƿ�Ϊ��
 *    @param         Q ����ָ��Q
 *    @return         : ��-TRUE; δ��-FALSE
 *  @notice      : None
 */
Status IsEmptyLQueue(const LQueue *Q)
{
	if(Q->length == 0)
	{
		return _TRUE;
	}
	return _FALSE;
}


/**
 *  @name        : Status GetHeadLQueue(LQueue *Q, void *e)
 *    @description : �鿴��ͷԪ��
 *    @param         Q e ����ָ��Q,��������ָ��e
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : �����Ƿ��
 */
Status GetHeadLQueue(LQueue *Q, void **e)
{
	void *dat;
	if(!IsEmptyLQueue(Q))
	{
		*e = Q->front->data;
		return _TRUE;
	}
	return _FALSE;
}


/**
 *  @name        : int LengthLQueue(LQueue *Q)
 *    @description : ȷ�����г���
 *    @param         Q ����ָ��Q
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : None
 */
int LengthLQueue(LQueue *Q)
{
	Node *Ser;
	int times = 0;

	for(Ser = Q->front; Ser != NULL; Ser = Ser->next)
	{
		times ++;
	}

	return times;
}


/**
 *  @name        : Status EnLQueue(LQueue *Q, void *data)
 *    @description : ��Ӳ���
 *    @param         Q ����ָ��Q,�������ָ��data
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : �����Ƿ�Ϊ��
 */
Status EnLQueue(LQueue *Q, void *data)
{
	if(IsEmptyLQueue(Q))
	{
		Q->length ++;
		Q->front = (Node *)malloc(sizeof(Node));
		Q->rear = Q->front;
		Q->rear->data = data;
		Q->rear->next = NULL;
		return _TRUE;
	}
	Q->length ++;
	Q->rear->next = (Node *)malloc(sizeof(Node));
	Q->rear = Q->rear->next;
	Q->rear->data = data;
	Q->rear->next = NULL;

	return _TRUE;
}


/**
 *  @name        : Status DeLQueue(LQueue *Q)
 *    @description : ���Ӳ���
 *    @param         Q ����ָ��Q
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : None
 */
Status DeLQueue(LQueue *Q)
{
	Node *temp;

	if(IsEmptyLQueue(Q))
	{
		return _FALSE;
	}
	Q->length --;
	temp = Q->front->next;
	free(Q->front);
	Q->front = temp;
	rear = (rear + 1) % 30;
}


/**
 *  @name        : void ClearLQueue(AQueue *Q)
 *    @description : ��ն���
 *    @param         Q ����ָ��Q
 *  @notice      : None
 */
void ClearLQueue(LQueue *Q)
{
	Node *nod, *temp;
	for(nod = Q->front; nod != NULL; )
	{
		temp = nod;
		nod = nod->next;
		free(temp);
	}
	Q->length = 0;
	Q->front = NULL;
	Q->rear = NULL;
	top = -1;
	rear = 0;
}


/**
 *  @name        : Status TraverseLQueue(const LQueue *Q, void (*foo)(void *q))
 *    @description : ������������
 *    @param         Q ����ָ��Q����������ָ��foo
 *    @return         : None
 *  @notice      : None
 */
Status TraverseLQueue(const LQueue *Q, void (*foo)(void *q, int i))
{
	Node *Ser;
	int i;

	i = rear;
	if(IsEmptyLQueue(Q))
	{
		return _FALSE;
	}
	for(Ser = Q->front; Ser != NULL; Ser = Ser->next)
	{
		foo(Ser->data, i);
		i ++;
	}
	return _TRUE;
}


/**
 *  @name        : void LPrint(void *q)
 *    @description : ��������
 *    @param         q ָ��q, i(��i��)
 *  @notice      : None
 */
void LPrint(void *q, int i)
{
	if(datatype[i] == 'i')
	{
		printf("%d  ", *(int *)q);
	}
	if(datatype[i] == 'c')
	{
		printf("%c  ", *(char *)q);
	}
	if(datatype[i] == 's')
	{
		printf("%s  ", (char *)q);
	}
	if(datatype[i] == 'f')
	{
		printf("%f  ", *(float *)q);
	}
}
/**
 *  @name        : void *GetData()
 *    @description : ��ȡ����
 *    @param         
 *  @notice      : None
 */
void *GetData()
{
	void *data = NULL;

	if(datatype[top] == 'i')
	{
		data = (int *)malloc(sizeof(int));
		scanf("%d", data);
	}
	if(datatype[top] == 'c')
	{
		data = (char *)malloc(sizeof(char));
		scanf("%c", data);
	}
	if(datatype[top] == 's')
	{
		data = (char *)malloc(100 * sizeof(int));
		scanf("%s", data);
	}
	if(datatype[top] == 'f')
	{
		data = (char *)malloc(sizeof(float));
		scanf("%f", data);
	}
	return data;
}


/**
 *  @name        : void *GetNum()
 *    @description : ��ȡ�Ϸ�����������
 *    @param         
 *  @notice      : None
 */
int GetNum()
{
	char data[100];
	int i;

	scanf_s("%s", data, 50);
	fflush(stdin);

	if(strlen(data) >= 10)
	{
		printf("You can only store up to 999999999 try again\n");
		return GetNum();
	}
	for(i = 0; (i < 9) && (data[i] != '\0'); i ++)
	{
		if(('0' > data[i]) || (data[i] > '9'))
		{
			printf("Your enter is illegal, Try again\n");
			return GetNum();                 //�ظ����ң�����ҵ��˾ͷ�����ȷ��ֵ
		}
	}
	return atoi(data);
}


/**
 *  @name        : void ChooseType()
 *    @description : ѡ����������
 *    @param         
 *  @notice      : None
 */
void ChooseType()
{
	system("CLS");
	HANDLE hdl = GetStdHandle(STD_OUTPUT_HANDLE);

	SetConsoleTextAttribute(hdl, FOR_INI_BLUE|SET_WHITE);
	printf("/*********���еĻ�������*********\\\n");
	printf("|****��ѡ�������ŵ���������****|\n");
	SetConsoleTextAttribute(hdl, FOR_INI_RED|SET_WHITE);
	printf("|****1.int                   ****|\n");
	printf("|****2.char                  ****|\n");
	printf("|****3.float                 ****|\n");
	printf("|****4.string                ****|\n");
	SetConsoleTextAttribute(hdl, FOR_INI_BLUE|SET_WHITE);
	printf("\\********************************/\n");

	top = (top + 1) % 30;
	switch(GetNum())
	{
	case 1:
		datatype[top] = 'i';
		break;
	case 2:
		datatype[top] = 'c';
		break;
	case 3:
		datatype[top] = 'f';
		break;
	case 4:
		datatype[top] = 's';
		break;
	default:
		top --;
		ChooseType();
	}
}


int main()
{
	LQueue que;
	int choice;
	void *data = NULL;
	HANDLE hdl = GetStdHandle(STD_OUTPUT_HANDLE);
	int flag = 0;
	system("color f7");

	while(1)
	{
		system("CLS");
		SetConsoleTextAttribute(hdl, FOR_INI_BLUE|SET_WHITE);
		printf("/*********���еĻ�������*********\\\n");
		SetConsoleTextAttribute(hdl, FOR_INI_RED|SET_WHITE);
		printf("|****1.InitLQueue            ****|\n");
		printf("|****2.DestoryLQueue         ****|\n");
		printf("|****3.IsEmptyLQueue         ****|\n");
		printf("|****4.GetHeadLQueue         ****|\n");
		printf("|****5.LengthLQueue          ****|\n");
		printf("|****6.EnLQueue              ****|\n");
		printf("|****7.DeLQueue              ****|\n");
		printf("|****8.ClearLQueue           ****|\n");
		printf("|****9.PrintQueue            ****|\n");
		SetConsoleTextAttribute(hdl, FOR_INI_BLUE|SET_WHITE);
		printf("\\********************************/\n");

		choice = GetNum();
		switch(choice)
		{
		SetConsoleTextAttribute(hdl, FOR_INI_RED|SET_WHITE);
		case 1:
			InitLQueue(&que);
			flag = 1;
			printf("Press any key to continue\n");
			break;
		case 2:
			if(flag)
			{
				DestoryLQueue(&que);
				printf("OK!\nPress any key to continue\n");
			}
			else
			{
				printf("ERROR:The queue haven't init\n");
			}
			break;
		case 3:
			if(!flag)
			{
				printf("ERROR:The queue haven't init\n");
				break;
			}
			if(IsEmptyLQueue(&que))
			{
				printf("The queue is empyt\n");
			}
			else
			{
				printf("The queue isn't empyt\n");
			}
			break;
		case 4:
			if(!flag)
			{
				printf("ERROR:The queue haven't init\n");
				break;
			}
			if(!IsEmptyLQueue(&que))
			{
				printf("The head of the queue is \n");
				GetHeadLQueue(&que, &data);
				LPrint(data, top);
			}
			else
			{
				printf("The queue is empty\n");
			}
			break;
		case 5:
			if(!flag)
			{
				printf("ERROR:The queue haven't init\n");
				break;
			}
			printf("The queue length is %d\n", LengthLQueue(&que));
			break;
		case 6:
			if(!flag)
			{
				printf("ERROR:The queue haven't init\n");
				break;
			}
			ChooseType();
			system("CLS");
			printf("Enter your data:\n");
			EnLQueue(&que, GetData());
			break;
		case 7:
			if(!flag)
			{
				printf("ERROR:The queue haven't init\n");
				break;
			}
			if(IsEmptyLQueue(&que))
			{
				printf("The queue is empty\n");
				break;
			}
			DeLQueue(&que);
			printf("OK\n");
			break;
		case 8:
			if(!flag)
			{
				printf("ERROR:The queue haven't init\n");
				break;
			}
			ClearLQueue(&que);
			break;
		case 9:
			if(!flag)
			{
				printf("ERROR:The queue haven't init\n");
				break;
			}
			if(IsEmptyLQueue(&que))
			{
				printf("The queue is empty\n");
				break;
			}
			TraverseLQueue(&que, LPrint);
			break;
		default:
			printf("No this choice\n");
		}
		getchar();
		fflush(stdin);
	}

	CloseHandle(hdl);
}


#endif
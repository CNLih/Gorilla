
#include"qgsort.h"

int stack[10000];
int top = -1;


long long getSystemTime() {
    struct timeb t;
    ftime(&t);
    return 1000 * t.time + t.millitm;
}

int pop()
{
	if(top != -1)
	{
		top --;
		return stack[top + 1];
	}
	else
	{
		return -1;
	}
}

void push(int data)
{
	stack[++ top] = data;
}


void insertSort(int *a,int n)
{
	int temp;
	int i, j;

	for(i = 1; i < n; i ++)
	{
		temp = a[i];
		for(j = i - 1; (j >= 0) && (temp < a[j]); j --)
		{
			a[j + 1] = a[j];
		}
		a[j + 1] = temp;
	}
}

void MergeArray(int *a,int begin,int mid,int end,int *temp)
{
	int k = begin;
	int i = begin, j = mid + 1;

	while (i <= mid && j <= end){
		if (a[i] <= a[j])
		{
			temp[k ++] = a[i++];
		}
		else
		{
			temp[k ++] = a[j++];
		}
	}
	while (i <= mid)
	{
		temp[k ++] = a[i ++];
	}
	while (j <= end)
	{
		temp[k ++] = a[j++];
	}
	memcpy(a + begin, temp + begin, sizeof(int)*(end - begin + 1));
}

void MergeSort(int *a,int begin,int end,int *temp)
{
	if (begin >= end)
	{
		return;
	}

	int mid = (begin + end)/2;
	MergeSort(a, begin, mid, temp);
	MergeSort(a, mid + 1, end, temp);
	MergeArray(a, begin, mid, end, temp);
}

void QuickSort_Recursion(int *a, int begin, int end)
{
	int i, j, k, temp;

	i = k = begin;
	j = begin + 1;
	
	while(j < end)                  //�������滻�������������鷳
	{
		if(a[j] < a[i])
		{
			k ++;
			temp = a[k];
			a[k] = a[j];
			a[j] = temp;
		}
		j ++;
	}
	temp = a[k];
	a[k] = a[i];
	a[i] = temp;

	if(k > i + 1)
	{
		QuickSort_Recursion(a, i, k - 1);
	}
	if(i < end)
	{
		QuickSort_Recursion(a, k + 1, end);
	}
}

void QuickSort(int *a,int size)
{
	int start, end, nend;
	start = 0;
	end = size - 1;

	nend = Partition(a, start, end);

	if(nend - 1 > start)           //ȷ���������ȳ���3��Ԫ��
	{
		push(start);
		push(nend - 1);
	}
	if(nend + 1 < end)
	{
		push(nend + 1);
		push(end);
	}
	while(top != -1)
	{
		end = pop();
		start = pop();
		nend = Partition(a, start, end);
		if(nend - 1 > start)           //ȷ���������ȳ���3��Ԫ��
		{
			push(start);
			push(nend - 1);
		}
		if(nend + 1 < end)
		{
			push(nend + 1);
			push(end);
		}
	}
}

int Partition(int *a, int begin, int end)          //���߶��ĸо�
{
	int cmp;

	cmp = a[begin];
	while(begin < end)
	{
		while((begin < end) && (a[end] >= cmp))
		{
			end --;
		}
		a[begin] = a[end];
		while((begin < end) && (a[begin] <= cmp))
		{
			begin ++;
		}
		a[end] = a[begin];
	}

	a[begin] = cmp;
	return begin;

}

void CountSort(int *a, int size , int max)
{
	int *arr;
	int i, k;

	arr = (int *)malloc(max * sizeof(int));

	memset(arr, 0, max * sizeof(int));
	for(i = 0; i < size; i ++)
	{
		*(arr + a[i]) = *(arr + a[i]) + 1;
	}
	k = 0;
	for(i = 0; i < size; i ++)
	{
		while(arr[i])
		{
			a[k ++] = i;
			arr[i] = arr[i] - 1;
		}
	}
	free(arr);
}

void RadixCountSort(int *a,int size)
{
	int bucket[10][5000] = {0};
	int flag[10];
	int k, w, p;
	int i, j, max;
	int num;

	max = a[0];
	for(i = 0; i < size; i ++)
	{
		if(max < a[i])
		{
			max = a[i];
		}
	}

	for(i = 0; max != 0; max /= 10)
	{
		p = 1;
		for(k = 0; k < i; k ++)
		{
			p *= 10;
		}
		memset(flag, 0, 10 * sizeof(int));
		for(j = 0; j < size; j ++)
		{
			num = (a[j] / p) % 10;
			bucket[num][flag[num] ++] = a[j];  //flag��Ӧ��λ����һ
		}
		i ++;
		k = 0;
		for(j = 0; j < 10; j ++)
		{
			for(w = 0; flag[j] > 0; k ++)
			{
				a[k] = bucket[j][w ++];     //ȡ��
				flag[j] --;
			}
		}
	}
}

void NewRandNum()
{
	FILE *fp;
	int i;

	srand((unsigned)time(NULL));
	fp = fopen("rand.txt", "w");
	for(i = 0; i < 50000; i ++)       //25w����
	{
		fprintf(fp, "%d %d %d %d %d ", rand()%5000, rand()%5000, rand()%5000, rand()%5000, rand()%5000);
	}
	fclose(fp);
}

int *GetArr(int num)
{
	FILE *fp;
	int *arr;
	int i;

	fp = fopen("rand.txt", "r");
	arr = (int *)malloc(num * sizeof(int));
	for(i = 0; i < num; i = i ++)
	{
		fscanf(fp, "%d", arr + i);
	}

	fclose(fp);
	return arr;
}

void ColorSort(int *a,int size)
{
	int i, j, k;

	i = 0;
	j = size - 1;
	for(k = 0; k < j;)
	{
		if(a[k] == 2)
		{
			a[k] = a[j];
			a[j] = 2;
			j --;
		}
		else if(a[k] == 0)
		{
			a[k] = a[i];
			a[i] = 0;
			i ++;
		}
		else
		{
			k ++;
		}
	}
}

int Findkth(int *a, int begin, int end, int find)
{
	int i, j, k, temp;

	i = k = begin;
	j = begin + 1;
	
	while(j < end)
	{
		if(a[j] < a[i])
		{
			k ++;
			temp = a[k];
			a[k] = a[j];
			a[j] = temp;
		}
		j ++;
	}
	temp = a[k];
	a[k] = a[i];
	a[i] = temp;

	if(find < k)
	{
		Findkth(a, i, k - 1, find);
	}
	if(find > k)
	{
		Findkth(a, k + 1, end, find);
	}
	if(find == k)
	{
		return a[k];
	}
}

int main()
{
	int i, j, times;
    int *arr;
	int *temp;
	int find;
	int a[20] = {1,2,0,2,1,1,0,2,1,0,2,1,0,0,2,1,0,2,1,0};
	int b[20] = {1,3,4,5,7,2,4,6,8,10,12,14,16,18,20,11,13,15,17,19};
	long long start;
	long long end;
	temp = (int *)malloc(100 * sizeof(int));

	printf("���ҵ�nС������\n");
	printf("���������ǣ�\n");
	for(i = 0; i < 20; i ++)
	{
		printf("%d ", b[i]);
	}
	printf("\n������ҵڼ�С������\n");
	scanf("%d", &find);
	printf("��%dС����Ϊ%d\n\n", find, Findkth(b, 0, 19, find));
//	NewRandNum();

	printf("��ɫ����ǰ��\n");
	for(i = 0; i < 20; i ++)
	{
		printf("%d ", a[i]);
	}
	ColorSort(a,20);
	printf("��ɫ�����\n");
	for(i = 0; i < 20; i ++)
	{
		printf("%d ", a[i]);
	}
	printf("\n");

	for(j = 0; j < 3; j ++)
	{
		if(j == 0)
		{
			times = 10000;
		}
		if(j == 1)
		{
			times = 50000;
		}
		if(j == 2)
		{
			times = 200000;
		}
		
		printf("%d�����\n", times);
		start=getSystemTime();
		
		arr = GetArr(times);
		insertSort(arr, times);

		end=getSystemTime();
		printf("\n");
		printf("��������: %lld ms\n", end-start);

		temp = (int *)malloc(times * sizeof(int));
		start=getSystemTime();
		
		arr = GetArr(times);
		MergeSort(arr, 0, times, temp);

		end=getSystemTime();
		printf("\n");
		printf("�鲢����: %lld ms\n", end-start);

		start=getSystemTime();

		arr = GetArr(times);
		QuickSort_Recursion(arr, 0, times);

		end=getSystemTime();
		printf("\n");
		printf("�鲢���ǵݹ飩����: %lld ms\n", end-start);

		start=getSystemTime();

		arr = GetArr(times);
		CountSort(arr, times, times);

		end=getSystemTime();
		printf("\n");
		printf("��������: %lld ms\n", end-start);

		start=getSystemTime();

		arr = GetArr(times);
		RadixCountSort(arr, 5000);

		end=getSystemTime();
		printf("\n");
		printf("��������: %lld ms\n", end-start);
		printf("\n");
	}


	printf("����С��������\n");
	start=getSystemTime();
	for(i = 0; i < 100000; i ++)      //100000��
	{
		arr = GetArr(100);
		insertSort(arr, 100);
	}
	end=getSystemTime();
	printf("\n");
	printf("��������: %lld ms\n", end-start);

	start=getSystemTime();
	for(i = 0; i < 100000; i ++)
	{
		arr = GetArr(100);
		MergeSort(arr, 0, 99, temp);
	}
	end=getSystemTime();
	printf("\n");
	printf("�鲢����: %lld ms\n", end-start);

	start=getSystemTime();
	for(i = 0; i < 100000; i ++)
	{
		arr = GetArr(100);
		QuickSort_Recursion(arr, 100, 99);
	}
	end=getSystemTime();
	printf("\n");
	printf("�鲢���ǵݹ飩����: %lld ms\n", end-start);

	start=getSystemTime();
	for(i = 0; i < 100000; i ++)
	{
		arr = GetArr(100);
		CountSort(arr, 100, 10000);
	}
	end=getSystemTime();
	printf("\n");
	printf("��������: %lld ms\n", end-start);

	start=getSystemTime();
	for(i = 0; i < 100000; i ++)
	{
		arr = GetArr(100);
		RadixCountSort(arr, 100);
	}
	end=getSystemTime();
	printf("\n");
	printf("��������: %lld ms\n", end-start);

	system("pause");
	return 0;
}
/***************************************************************************************
 *    File Name                :    LinkBiTree.h
 *    CopyRight                :
 *
 *    SYSTEM                   :   win7
 *    Create Data              :    2020.4.26
 *    Author/Corportation      :  lh
 *
 *
 *--------------------------------Revision History--------------------------------------
 *    No    version        Data            Revised By            Item            Description
 *
 *
 ***************************************************************************************/

#ifndef BINARYTREE_H_INCLUDED
#define BINARYTREE_H_INCLUDED


//macro define
#define isopt(x)    (x) == '+' || (x) == '-' || (x) == '*' || (x) == '/'
#define BACKGROUND_WHITE 0x0070
#define FOR_INI_RED      FOREGROUND_RED|FOREGROUND_INTENSITY
#define FOR_INI_BLUE     FOREGROUND_BLUE|FOREGROUND_INTENSITY
#define SET_WHITE        BACKGROUND_INTENSITY|BACKGROUND_WHITE


//include
#include <windows.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>


//struct define
typedef char TElemType;     // 假设二叉树结点的元素类型为字符

typedef struct BiTNode {
    TElemType      data;     // 数据域
    struct BiTNode  *lchild,*rchild;  // 左、右孩子指针
} BiTNode, *BiTree;   // 二叉链表


typedef enum Status{
	_SUCCESS = 1,
	_ERROR = 0,
}Status;

typedef struct QueueNode
{
	BiTree data;
	struct QueueNode *next;
}QueueNode;

typedef struct LQueue
{
	QueueNode *front;
	QueueNode *rear;
}LQueue;


//declare
/**
 *  @name        : Status InitBiTree(BiTree T);
 *  @description : 构造空二叉树T
 *  @param       : 二叉树根结点T
 */
Status InitBiTree(BiTree *T);


/**
 *  @name        : Status DestroyBiTree(BiTree T);
 *  @description : 摧毁二叉树T
 *  @param       : 二叉树根结点T
 */
Status DestroyBiTree(BiTree T);


/**
 *  @name        : Status CreateBiTree(BiTree T, char* definition);
 *  @description : 构造二叉树T
 *  @param       : 二叉树根结点T, 二叉树先序遍历字符串definition
 */
Status CreateBiTree(BiTree T, char* definition);


/**
 *  @name        : Status PreOrderTraverse(BiTree T, Status (*visit)(TElemType e));
 *  @description : 先序遍历二叉树T
 *  @param       : 二叉树根结点T, 对结点的操作函数visit
 */
Status PreOrderTraverse(BiTree T, Status (*visit)(TElemType e));


/**
 *  @name        : Status InOrderTraverse(BiTree T, Status (*visit)(TElemType e));
 *  @description : 中序遍历二叉树T
 *  @param       : 二叉树根结点T, 对结点的操作函数visit
 */
Status InOrderTraverse(BiTree T, Status (*visit)(TElemType e));


/**
 *  @name        : Status PostOrderTraverse(BiTree T, Status (*visit)(TElemType e)));
 *  @description : 后序遍历二叉树T
 *  @param       : 二叉树根结点T, 对结点的操作函数visit
 */
Status PostOrderTraverse(BiTree T, Status (*visit)(TElemType e));


/**
 *  @name        : Status LevelOrderTraverse(BiTree T, Status (*visit)(TElemType e));
 *  @description : 层序遍历二叉树T
 *  @param       : 二叉树根结点T, 对结点的操作函数visit
 */
Status LevelOrderTraverse(BiTree T, Status (*visit)(TElemType e));


/**
 *  @name        : int Value(BiTree T);
 *  @description : 对构造出的前缀表达式二叉树求值
 *  @param       : 二叉树根结点T
 *  @note        : 可在结点结构体中设置个Tag值标志数字与操作符来构造二叉树，
 *                 可根据需要自行增加操作.
 */
int Value(BiTree T);

#endif

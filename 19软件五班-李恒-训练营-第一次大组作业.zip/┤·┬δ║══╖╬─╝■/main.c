/***************************************************************************************
 *	File Name				:	main.c
 *	CopyRight				:	lih
 *	SYSTEM					:   win7
 *	Create Data				:	2020.4.1
 *
 *
 *--------------------------------Revision History--------------------------------------
 *	No	version		Data			Revised By			Item			Description
 *
 *
 ***************************************************************************************/

#include "../head/main.h"

// define Type
typedef enum ListType {
	Unknown,
	SgLinkedlist,
	DbLinkedlist
} ListType;

//visit
void PrintData(ElemType e)
{
	printf("%d ", e);
}

//List arg
typedef struct List
{
	char name[12];
	ListType Type;
}List;

//Single List arg
typedef struct SgList
{
	List List;
	LinkedList HeadNode;
}SgList;
SgList EmptySg = {{{'\0'}, Unknown}, NULL};

//Du List arg
typedef struct DbList
{
	List List;
	DuLinkedList HeadNode;
}DbList;
DbList EmptyDb = {{{'\0'}, Unknown}, NULL};

//lib
SgList SgListlib[10];     //ʮ����������˫�����Ĵ���ռ�
DbList DbListlib[10];
int Sg[10] = {0};         //�����Ӧ��λ��0Ϊ�գ�1Ϊ��
int Db[10] = {0};
int AllList = 0;

int GetNum()
{
	char data[2];
	int i;

	scanf_s("%s", data, 2);
	fflush(stdin);
	for(i = 0; (i < 2) && (data[i] != '\0'); i ++)
	{
		if(('0' > data[i]) || (data[i] > '9'))
		{
			printf("Your enter is illegal, Try again\n");
			return GetNum();                 //�ظ����ң�����ҵ��˾ͷ�����ȷ��ֵ
		}
	}
	return atoi(data);
}

int TranData(char data[20])
{
	int i;

	for(i = 0; (i < 20) && (data[i] != '\0'); i ++)
	{
		if(('0' > data[i]) || (data[i] > '9'))
		{
			printf("Your enter is illegal, Try after the error begin\n");
			                                    //�������������EOF���޷������ģ���֪����ô���
			fflush(stdin);
			scanf_s("%s", data, 20);
			return TranData(data);                 //�ظ����ң�����ҵ��˾ͷ�����ȷ��ֵ
		}
	}
	return atoi(data);
}

Status IfOccupy(char name[11])
{
	int i;

	for(i = 0; i < 10; i ++)
	{
		if(Db[i])
		{
			if(strcmp(DbListlib[i].List.name, name) == 0)
			{
				return SUCCESS;
			}
		}
		if(Sg[i])
		{
			if(strcmp(SgListlib[i].List.name, name) == 0)
			{
				return SUCCESS;
			}
		}
	}
	return ERROR;
}

Status CreateSgList()
{
	int i;
	char name[12];
	char Data[20];
	LinkedList Head = NULL;
	LinkedList temp1, temp2 = NULL;

//whether lib is full
	for(i = 0; i < 10; i ++)
	{
		if(Sg[i] == 0)
		{
			break;
		}
		if((i == 9) && (Sg[9] == 1))
		{
			printf("The Single List lib is full,create List fail\n");
			return ERROR;
		}
	}

	Sg[i] = 1;
	SgListlib[i].List.Type = SgLinkedlist;

//get name	
	printf("Name(under 10 char):");

	while(1)
	{
		scanf_s("%s", name, 10);
		if(!((strlen(name) > 10) || (IfOccupy(name))))
		{
			break;
		}
		printf("It is illegal!\n");
		printf("Name(under 10 char):");
	}
	strcpy(SgListlib[i].List.name, name);

//get data
	printf("Enter the data control + z to end\n");

	while(scanf_s("%s", Data, 20) != EOF)
	{
		InitList(&temp1);
		temp1->data = TranData(Data);
		if(temp2 == NULL)
		{
			SgListlib[i].HeadNode = temp1;
		}
		else
		{
		temp2->next = temp1;
		}
		temp2 = temp1;
	}

	printf("OK, you create a SgList:\n");
	printf("%s\n", SgListlib[i].List.name);
	TraverseList(SgListlib[i].HeadNode, PrintData);
	getchar();
	fflush(stdin);

	AllList ++;
	return SUCCESS;
}

Status CreateDbList()
{
	int i;
	char name[12];
	char Data[20];
	ElemType data;
	DuLinkedList Head = NULL;
	DuLinkedList temp1, temp2 = NULL;

//whether lib is full
	for(i = 0; i < 10; i ++)
	{
		if(Db[i] == 0)
		{
			break;
		}
		if((i == 9) && (Sg[9] == 1))
		{
			printf("The DuList lib is full,create List fail\n");
			return ERROR;
		}
	}

	Db[i] = 1;
	DbListlib[i].List.Type = DbLinkedlist;

//get name	
	printf("Name(under 10 char):");
	
	while(1)
	{
		scanf("%s", name);
		if(!((strlen(name) > 10) || (IfOccupy(name))))
		{
			break;
		}
		printf("It is illegal!\n");
		printf("Name(under 10 char):");
	}
	strcpy(DbListlib[i].List.name, name);

//get data
	printf("Enter the data control + z to end\n");

	while(scanf_s("%s", Data, 20) != EOF)
	{
		InitList_DuL(&temp1);
		data = TranData(Data);
		temp1->data = data;
		if(temp2 == NULL)
		{
			DbListlib[i].HeadNode = temp1;
		}
		else
		{
		temp2->next = temp1;
		temp1->prior = temp2;
		}
		temp2 = temp1;
	}

	printf("OK, you create a DbList:\n");
	printf("%s\n", DbListlib[i].List.name);
	TraverseList_DuL(DbListlib[i].HeadNode, PrintData);
	getchar();
	fflush(stdin);
	AllList ++;
	return SUCCESS;
}

void DisplayList()
{
	int i, times1, times2;

	times1 = 0;
	for(i = 0; i < 10; i ++)      //if SgList empty print nothing
	{
		times1 += Sg[i];
	}
	if(times1)
	{
		printf("Single Linked List are following:\n");
	}

	for(i = 0; i < 10; i ++)
	{
		if(Sg[i])
		{
			printf("%s\n", SgListlib[i].List.name);
			TraverseList(SgListlib[i].HeadNode, PrintData);
			printf("\n");
		}
	}

	times2 = 0;
	for(i = 0; i < 10; i ++)    //if DbList empty print nothing
	{
		times2 += Db[i];
	}
	if(times2)
	{
		printf("DuLinked List are following:\n");
	}
	for(i = 0; i < 10; i ++)
	{
		if(Db[i])
		{
			printf("%s\n", DbListlib[i].List.name);
			TraverseList_DuL(DbListlib[i].HeadNode, PrintData);
			printf("\n");
		}
	}

	if(AllList == 0)
	{
		printf("The list lib is empty");
	}
	getchar();
	fflush(stdin);
}

void CreateList()
{
	int judge = 1;

	while(judge)
	{
		printf("Type(1.Single/2.DuList):");
		switch (GetNum())
		{
		case 1:
			CreateSgList();
			judge = 0;
			break;
		case 2:
			CreateDbList();
			judge = 0;
			break;
		default:
			printf("No this option, try again");
			getchar();
			fflush(stdin);
		}
	}
}

void Destory(char name[])
{
	int i;

	for(i = 0; i < 10; i ++)
	{
		if(Sg[i])
		{
			DestroyList(&(SgListlib[i].HeadNode));
			SgListlib[i] = EmptySg;
			Sg[i] = 0;
			break;
		}
		if((Db[i]) && (strcmp(DbListlib[i].List.name, name) == 0))
		{
			DestroyList_DuL(&DbListlib[i].HeadNode);
			DbListlib[i] = EmptyDb;
			Db[i] = 0;
			break;
		}
	}
	AllList --;
}

void Reverse(char name[])
{
	int i;

	for(i = 0; i < 10; i ++)
	{
		if((Sg[i]) && (strcmp(SgListlib[i].List.name, name) == 0))
		{
			ReverseList(&(SgListlib[i].HeadNode));
			printf("The new list:\n");
			printf("%s\n", name);
			TraverseList(SgListlib[i].HeadNode, PrintData);

			getchar();
			fflush(stdin);
			break;
		}
		if((Db[i]) && (strcmp(DbListlib[i].List.name, name) == 0))
		{
			printf("Sorry, this function only use for single List\n");
			break;
		}
	}
}

void REvenList(char name[])
{
	int i;

	for(i = 0; i < 10; i ++)
	{
		if((Sg[i]) && (strcmp(SgListlib[i].List.name, name) == 0))
		{
			SgListlib[i].HeadNode = ReverseEvenList(&(SgListlib[i].HeadNode));
			printf("The new list:\n");
			printf("%s\n", name);
			TraverseList(SgListlib[i].HeadNode, PrintData);

			getchar();
			fflush(stdin);
			break;
		}
		if((Db[i]) && (strcmp(DbListlib[i].List.name, name) == 0))
		{
			printf("Sorry, this function only use for single List\n");
			break;
		}
	}
}

void Find(char name[])
{
	int i;

	for(i = 0; i < 10; i ++)
	{
		if((Sg[i]) && (strcmp(SgListlib[i].List.name, name) == 0))
		{
			FindMidNode(&(SgListlib[i].HeadNode));
			break;
		}
		if((Db[i]) && (strcmp(DbListlib[i].List.name, name) == 0))
		{
			printf("Sorry, this function only use for single List\n");
			getchar();
			fflush(stdin);
			break;
		}
	}
}

void AddNode(char name[])
{
	int i;
	char Data[20];
	LinkedList temp, NewNode;
	DuLinkedList temp2, NewNode2;

	for(i = 0; i < 10; i ++)
	{
		if((Sg[i]) && (strcmp(SgListlib[i].List.name, name) == 0))
		{
			for(temp = SgListlib[i].HeadNode; temp->next != NULL;)
			{
				temp = temp->next;
			}
			printf("Enter the data control + z to end\n");

			while(scanf_s("%s", Data, 20) != EOF)
			{
				InitList(&NewNode);
				NewNode->data = TranData(Data);
				InsertList(temp, NewNode);
				temp = NewNode;
			}
			printf("The new list:\n");
			printf("%s\n", name);
			TraverseList(SgListlib[i].HeadNode, PrintData);

			getchar();
			fflush(stdin);
			break;
		}
		if((Db[i]) && (strcmp(DbListlib[i].List.name, name) == 0))
		{
			for(temp2 = DbListlib[i].HeadNode; temp2->next != NULL;)
			{
				temp2 = temp2->next;
			}
			printf("Enter the data control + z to end\n");

			while(scanf_s("%s", Data, 20) != EOF)
			{
				InitList_DuL(&NewNode2);
				NewNode2->data = TranData(Data);
				InsertAfterList_DuL(temp2, NewNode2);
				temp2 = NewNode2;
			}
			printf("The new list:\n");
			printf("%s\n", name);
			TraverseList_DuL(DbListlib[i].HeadNode, PrintData);

			getchar();
			fflush(stdin);
			break;
		}
	}
}

void InsertNode(char name[])
{
	int i, fit = 0, data;
	char Data[20];
	LinkedList temp, NewNode;
	DuLinkedList temp2, NewNode2;

	for(i = 0; i < 10; i ++)
	{
		if((Sg[i]) && (strcmp(SgListlib[i].List.name, name) == 0))
		{
			printf("Enter the data you want to insert after:");
			TraverseList(SgListlib[i].HeadNode, PrintData);
			printf("\n");
			do                       //�ҵ���Ӧ��data
			{
				scanf_s("%s", Data, 20);
				data = TranData(Data);
				temp = SgListlib[i].HeadNode;
				for(; temp != NULL; temp = temp->next)
				{
					if(temp->data == data)
					{
						fit = 1;
						break;
					}
				}
			}while(!fit);

			printf("Enter the data control + z to end\n");

			while(scanf_s("%s", Data, 20) != EOF)   //��data�����������
			{
				InitList(&NewNode);
				NewNode->data = TranData(Data);
				if(temp->next != NULL)
				{
					InsertList(NewNode, temp->next);
				}
				InsertList(temp, NewNode);
				temp = NewNode;
			}
			printf("The new list:\n");
			printf("%s\n", name);
			TraverseList(SgListlib[i].HeadNode, PrintData);

			getchar();
			fflush(stdin);
			break;
		}
		//˫�������͵���������������ͳһ
		if((Db[i]) && (strcmp(DbListlib[i].List.name, name) == 0))
		{
			printf("Enter the data you want to insert after:");
			TraverseList_DuL(DbListlib[i].HeadNode, PrintData);
			printf("\n");
			do
			{
				data = GetNum();
				temp2 = DbListlib[i].HeadNode;
				for(; temp2 != NULL; temp2 = temp2->next)
				{
					if(temp2->data == data)
					{
						fit = 1;
						break;
					}
				}
			}while(!fit);
			printf("Enter the data control + z to end\n");

			while(scanf_s("%s", Data, 20) != EOF)
			{
				InitList_DuL(&NewNode2);
				NewNode2->data = TranData(Data);
				if(temp2->next != NULL)
				{
					InsertAfterList_DuL(NewNode2, temp2->next);
				}
				InsertAfterList_DuL(temp2, NewNode2);
				temp2 = NewNode2;
			}
			printf("The new list:\n");
			printf("%s\n", name);
			TraverseList_DuL(DbListlib[i].HeadNode, PrintData);

			getchar();
			fflush(stdin);
			break;
		}
	}
}

void DeleteNode(char name[])
{
	int i, fit = 0;
	ElemType data;
	LinkedList temp;
	DuLNode *temp2;

	for(i = 0; i < 10; i ++)
	{
		if((Sg[i]) && (strcmp(SgListlib[i].List.name, name) == 0))
		{
			printf("Enter the data you want to delete:\n");
			TraverseList(SgListlib[i].HeadNode, PrintData);
			printf("\n");
			do                       //�ҵ���ɾ��������
			{
				data = GetNum();
				temp = SgListlib[i].HeadNode;
				for(; temp->next != NULL; temp = temp->next)
				{
					if(temp->next->data == data)
					{
						fit = 1;
						DeleteList(temp, &data);
						break;
					}
				}
				if((temp->next == NULL) && (temp->data) == data) //���ɾ������ͷ�ڵ�
				{
					SgListlib[i].HeadNode = temp->next;
					free(temp);
				}
			}while(!fit);
			
			printf("The new list:\n");
			printf("%s\n", name);
			TraverseList(SgListlib[i].HeadNode, PrintData);
			break;
		}

		if((Db[i]) && (strcmp(DbListlib[i].List.name, name) == 0))
		{
			printf("Enter the data you want to delete:");
			TraverseList_DuL(DbListlib[i].HeadNode, PrintData);
			printf("\n");
			do                       //�ҵ���ɾ��������
			{
				data = GetNum();
				temp2 = DbListlib[i].HeadNode;
				for(; temp2->next != NULL; temp2 = temp2->next)
				{
					if(temp2->next->data == data)
					{
						fit = 1;
						DeleteList_DuL(temp2, &data);
						break;
					}
				}
				if((temp2->next == NULL) && (temp2->data) == data) //���ɾ������ͷ�ڵ�
				{
					SgListlib[i].HeadNode = temp2->next;
					free(temp2);
				}
			}while(!fit);
			
			printf("The new list:\n");
			printf("%s\n", name);
			TraverseList(DbListlib[i].HeadNode, PrintData);
			break;
		}
		getchar();
		fflush(stdin);
	}
}

func fun_arry[8] = {NULL, Destory, Reverse, REvenList, Find, AddNode, InsertNode, DeleteNode};

Status MotiFun(void (*fun)(char name[11]))
{			
	char name[11];

	printf("Choose a List:\n");	
	printf("(enter its name)\n");
	while(1)
	{
		scanf_s("%s", name, 10);
		fflush(stdin);
	
		if(!IfOccupy(name))
		{
			printf("It is inexist\n");
			printf("Here is name of the List\n");
			DisplayList();
			printf("Try again\n");
			continue;
		}
		break;
	}
	fun(name);
	printf("OK\n");
	return SUCCESS;
}

void OperateList()
{
	int SeleN;
	int Doing = 1;

	while(Doing)
	{
		system("CLS");
		printf("/************************************\\\n");
		printf("1.Destory List\n");
		printf("2.ReverseList\n");
		printf("3.ReverseEvenList\n");
		printf("4.Find mid Node\n");
		printf("5.Add node in the end of the List\n");
		printf("6.Insert node\n");
		printf("7.Delete node\n");
		printf("9.back\n");
		printf("Please enter 1/2/3/4/5/6/7/9\n");
		printf("\\************************************/\n");
		SeleN = GetNum();
		switch (SeleN)
		{
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
			MotiFun(fun_arry[SeleN]);
			break;
		case 9:
			Doing = 0;
			break;
		default:
			printf("No this option, try again");
			getchar();
			fflush(stdin);
		}
	}
}

int main()
{
	while(1)
	{
		printf("/************************************\\\n");
		printf("1.Show all List\n");
		printf("2.Create a List\n");
		printf("3.Change a List\n");
		printf("9.End programe\n");
		printf("Please enter 1/2/3\n");
		printf("\\************************************/\n");
		switch (GetNum())
		{
		case 1:
			DisplayList();
			break;
		case 2:
			CreateList();
			break;
		case 3:
			if(AllList != 0)
			{
				OperateList();
			}
			else
			{
				printf("Sorry you have no List exist");
				getchar();
				fflush(stdin);
			}
			break;
		case 9:
			return 0;
		default:
			printf("No this option, try again");
			getchar();
			fflush(stdin);
		}
		system("CLS");
	}
}


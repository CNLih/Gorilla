/***************************************************************************************
 *	File Name				:	LinkStack.cpp
 *	CopyRight				:	lih
 *	SYSTEM					:   win7
 *	Create Data				:	2020.4.2
 *
 *
 *--------------------------------Revision History--------------------------------------
 *	No	version		Data			Revised By			Item			Description
 *
 *
 ***************************************************************************************/


#include"../LinkStack.h"

//��ȡ����
int GetNum()
{
	char data[100];
	int i;

	scanf_s("%s", data, 50);
	fflush(stdin);

	if(strlen(data) >= 10)
	{
		printf("You can only store up to 999999999 try again\n");
		return GetNum();
	}
	for(i = 0; (i < 9) && (data[i] != '\0'); i ++)
	{
		if(('0' > data[i]) || (data[i] > '9'))
		{
			printf("Your enter is illegal, Try again\n");
			return GetNum();                 //�ظ����ң�����ҵ��˾ͷ�����ȷ��ֵ
		}
	}
	return atoi(data);
}

//��ʼ��ջ
Status initLStack(LinkStack *s)
{
	if(s->top != NULL)
	{
		printf("The stack have been init\n");
		return ERROR;
	}
	s->count = 0;
	s->top = (LinkStackPtr)malloc(sizeof(StackNode));

	return SUCCESS;
}

//�ж�ջ�Ƿ�Ϊ��
Status isEmptyLStack(LinkStack *s)
{
	if(s->top == NULL)
	{
		printf("The stack havent init\n");
		return SUCCESS;
	}
	if(s->count == 0)
	{
		return SUCCESS;
	}
	else
	{
		return ERROR;
	}
}

//�õ�ջ��Ԫ��
Status getTopLStack(LinkStack *s,ElemType *e)
{
	int i;
	LinkStackPtr temp;

	if(isEmptyLStack(s))
	{
		printf("Empty\n");
		return ERROR;
	}
	temp = s->top;
	for(i = 1; i < s->count; i ++)
	{
		temp = temp->next;
	}
	*e = temp->data;

	return SUCCESS;
}

//���ջ
Status clearLStack(LinkStack *s)
{
	int i;
	LinkStackPtr temp1, temp2;

	if(isEmptyLStack(s))
	{
		printf("The stack is empty\n");
		return ERROR;
	}
	temp1 = s->top;
	for(i = 1; i < s->count; i ++)
	{
		temp2 = temp1->next;
		free(temp1);
		temp1 = temp2;
	}
	s->count = 0;
	temp1->data = 0;

	return SUCCESS;
}

//����ջ
Status destroyLStack(LinkStack *s)
{
	if(clearLStack(s))
	{
		s->top = NULL;
	}

	return SUCCESS;
}

//���ջ����
Status LStackLength(LinkStack *s,int *length)
{
	if(s->top == NULL)
	{
		printf("The Stack havet init\n");
		return ERROR;
	}
	*length = s->count;

	return SUCCESS;
}

//��ջ
Status pushLStack(LinkStack *s,ElemType data)
{
	int i;
	LinkStackPtr temp, NewNode;

	if(s->count == 0)
	{
		s->top->data = data;
		s->count ++;
		return SUCCESS;
	}

	temp = s->top;
	for(i = 1; i < s->count; i ++)
	{
		temp = temp->next;
	}
	NewNode = (LinkStackPtr)malloc(sizeof(StackNode));
	temp->next = NewNode;
	NewNode->data = data;
	s->count ++;

	return SUCCESS;
}

//��ջ
Status popLStack(LinkStack *s,ElemType *data)
{
	int i;
	LinkStackPtr temp;

	if(s->top == NULL)
	{
		printf("The Stack havet init\n");
		return ERROR;
	}
	if(isEmptyLStack(s))
	{
		printf("The stack is empty\n");
		return ERROR;
	}
	if(s->count == 1)
	{
		*data = s->top->data;
		s->top->data = 0;
		s->count --;
		return SUCCESS;
	}
	temp = s->top;
	for(i = 1; i < s->count; i ++)
	{
		temp = temp->next;
	}
	*data = temp->data;
	free(temp);
	s->count --;

	return SUCCESS;
}

int main()
{
	LinkStack *s;
	ElemType data = 0;
	s = (LinkStack *)malloc(sizeof(LinkStack));
	*s = EptLkStack;

	while(1)
	{
		printf("1.initLStack\n");
		printf("2.isEmptyLStack\n");
		printf("3.getTopLStack\n");
		printf("4.clearLStack\n");
		printf("5.destroyLStack\n");
		printf("6.stackLLength\n");
		printf("7.pushLStack\n");
		printf("8.popLStack\n");

		switch(GetNum())
		{
		case 1:
			if(s->top != NULL)
			{
				printf("There already have a stack,destory it first\n");
				break;
			}
			initLStack(s);
			break;
		case 2:
			if(s->top == NULL)
			{
				printf("The Stack havet init\n");
				break;
			}
			if(isEmptyLStack(s))
			{
				printf("The stack is empty\n");
			}
			else
			{
				printf("It is not empty\n");
			}
			break;
		case 3:
			if(getTopLStack(s, &data))
			{
				printf("Top data is %d\n", data);
			}
			break;
		case 4:
			if(clearLStack(s))
			{
				printf("OK\n");
			}
			break;
		case 5:
			destroyLStack(s);
			printf("OK\n");
			break;
		case 6:
			LStackLength(s, &data);
			printf("Stack length is %d\n", data);
			break;
		case 7:
			if(s->top == NULL)
			{
				printf("The Stack havet init\n");
				break;
			}
			printf("Enter a num:\n");
			if(pushLStack(s, GetNum()))
			{
				printf("OK\n");
			}
			break;
		case 8:
			if(popLStack(s, &data))
			{
				printf("You take out the data %d\n", data);
			}
			break;

		default:
			printf("No this choice\n");
		}
		getchar();
		system("CLS");
	}
}

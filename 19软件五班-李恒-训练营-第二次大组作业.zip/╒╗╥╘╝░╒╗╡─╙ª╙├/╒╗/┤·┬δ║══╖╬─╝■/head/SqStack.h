/***************************************************************************************
 *	File Name				:	SqStack.h
 *	CopyRight				:	lih
 *	SYSTEM					:   win7
 *	Create Data				:	2020.4.4
 *
 *
 *--------------------------------Revision History--------------------------------------
 *	No	version		Data			Revised By			Item			Description
 *
 *
 ***************************************************************************************/

 /**************************************************************
*	Multi-Include-Prevent Section
**************************************************************/

#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED

/**************************************************************
*	Includes Section
**************************************************************/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/**************************************************************
*	Macro Define Section
**************************************************************/


/**************************************************************
*	Struct Define Section
**************************************************************/

typedef enum Status 
{
	ERROR = 0, SUCCESS = 1
} Status;

typedef int ElemType;

typedef struct SqStack 
{
	ElemType *elem;
	int top;
	int size;
} SqStack;
SqStack EptSqStack = {NULL, -1, 0};


/**************************************************************
*	Prototype Declare Section
**************************************************************/

//���������˳��ջ
Status initStack(SqStack *s,int sizes);//��ʼ��ջ
Status isEmptyStack(SqStack *s);//�ж�ջ�Ƿ�Ϊ��
Status getTopStack(SqStack *s,ElemType *e); //�õ�ջ��Ԫ��
Status clearStack(SqStack *s);//���ջ
Status destroyStack(SqStack *s);//����ջ
Status stackLength(SqStack *s,int *length);//���ջ����
Status pushStack(SqStack *s,ElemType data);//��ջ
Status popStack(SqStack *s,ElemType *data);//��ջ


#endif 

#include <reg52.h>

sbit D1 = P0^6;
sbit D2 = P0^7;
char time;
char dig[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};

void MyDelay(int time)
{
		unsigned int i = 0;
		for (i = 0; i < time; i++);	
}

void Digtal()
{
	char i;
	
	D2 = 0;
	D1 = 1;
	MyDelay(5);
	P2 = 0x00;
	P2 = ~dig[time / 10];
	D1 = 0;
	D2 = 1;
	MyDelay(5);
	P2 = 0x00;
	P2 = ~dig[time % 10];
}

void ExtInt0() interrupt 0
{
	time ++;
	if(time == 100)
	{
		time = 0;
	}
}

void main()
{
  char cnt;

	EA = 1;
	EX0 = 1;
	IT0 = 1;
	cnt = 0;
	time = 0;
	
  while (1)
	{
		Digtal();
	}
}
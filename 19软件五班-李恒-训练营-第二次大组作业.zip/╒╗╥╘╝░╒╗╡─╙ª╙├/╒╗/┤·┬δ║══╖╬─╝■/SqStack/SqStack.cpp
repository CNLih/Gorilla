/***************************************************************************************
 *	File Name				:	SqStack.cpp
 *	CopyRight				:	lih
 *	SYSTEM					:   win7
 *	Create Data				:	2020.4.2
 *
 *
 *--------------------------------Revision History--------------------------------------
 *	No	version		Data			Revised By			Item			Description
 *
 *
 ***************************************************************************************/


#include"../SqStack.h"

//��ȡ����
int GetNum()
{
	char data[100];
	int i;

	scanf_s("%s", data, 50);
	fflush(stdin);

	if(strlen(data) >= 10)
	{
		printf("You can only store up to 999999999 try again\n");
		return GetNum();
	}
	for(i = 0; (i < 9) && (data[i] != '\0'); i ++)
	{
		if(('0' > data[i]) || (data[i] > '9'))
		{
			printf("Your enter is illegal, Try again\n");
			return GetNum();                 //�ظ����ң�����ҵ��˾ͷ�����ȷ��ֵ
		}
	}
	return atoi(data);
}

//��ʼ��ջ
Status initStack(SqStack *s,int sizes)
{
	s->size = sizes;
	s->elem = (ElemType *)malloc(sizes * sizeof(ElemType));

	if(s == NULL)
	{
		printf("Cant init Stack\n");

		return ERROR;
	}
	s->top = -1;

	return SUCCESS;
}

//�ж�ջ�Ƿ�Ϊ��
Status isEmptyStack(SqStack *s)
{
	if(s->top == -1)
	{
		return SUCCESS;
	}

	return ERROR;
}

//�õ�ջ��Ԫ��
Status getTopStack(SqStack *s,ElemType *e)
{
	if(isEmptyStack(s))
	{
		printf("Here is nothing\n");
		return ERROR;
	}
	else
	{
		*e = *((s->elem) + s->top);
	}
	return SUCCESS;
}

//���ջ
Status clearStack(SqStack *s)
{
	s->top = -1;
	return SUCCESS;
}

//����ջ
Status destroyStack(SqStack *s)
{
	free(s->elem);
	(*s) = EptSqStack;
	return SUCCESS;
}

//���ջ����
Status stackLength(SqStack *s,int *length)
{
	if(s->elem == NULL)
	{
		printf("The SqStack havent init\n");
		return ERROR;
	}
	*length = s->top + 1;
	return SUCCESS;
}

//��ջ
Status pushStack(SqStack *s,ElemType data)
{
	if(s->size == s->top + 1)
	{
		printf("The Stack is full\n");
		return ERROR;
	}
	s->top = s->top + 1;
	*(s->elem + s->top) = data;
	
	return SUCCESS;
}

//��ջ
Status popStack(SqStack *s,ElemType *data)
{
	if(s->top == -1)
	{
		printf("The stack is Empty\n");
		return ERROR;
	}
	*data = *(s->elem + s->top);
	s->top = s->top - 1;

	return SUCCESS;
}


int main()
{
	SqStack *s;
	ElemType data = 0;
	s = (SqStack *)malloc(sizeof(SqStack));
	*s = EptSqStack;

	while(1)
	{
		printf("1.initSqStack\n");
		printf("2.isEmptyStack\n");
		printf("3.getTopStack\n");
		printf("4.clearStack\n");
		printf("5.destroyStack\n");
		printf("6.stackLength\n");
		printf("7.pushStack\n");
		printf("8.popStack\n");
		switch(GetNum())
		{
		case 1:
			if(s->elem != NULL)
			{
				printf("There already have a stack,destory it first\n");
				break;
			}
			printf("How many data you want to store:\n");
			initStack(s, GetNum());
			break;
		case 2:
			if(isEmptyStack(s))
			{
				printf("The stack is empty\n");
			}
			else
			{
				printf("It is not empty\n");
			}
			break;
		case 3:
			if(getTopStack(s, &data))
			{
				printf("Top data is %d\n", data);
			}
			break;
		case 4:
			if(clearStack(s))
			{
				printf("OK\n");
			}
			break;
		case 5:
			destroyStack(s);
			printf("OK\n");
			break;
		case 6:
			stackLength(s, &data);
			printf("Stack length is %d\n", data);
			break;
		case 7:
			printf("Enter a num:\n");
			if(pushStack(s, GetNum()))
			{
				printf("OK\n");
			}
			break;
		case 8:
			if(popStack(s, &data))
			{
				printf("You take out the data %d\n", data);
			}
			break;

		default:
			printf("No this choice\n");
		}
		getchar();
		system("CLS");
	}
}
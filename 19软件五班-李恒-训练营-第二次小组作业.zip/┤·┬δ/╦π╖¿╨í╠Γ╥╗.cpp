/*Ѱ������Ĵ�*/
/*������ o(n)*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()
{
	char OgData[1006];
	char CgData[2006];
	int i, len;

	printf("�������ַ�����\n");
	scanf("%s", OgData);

	CgData[0] = '~';
	CgData[1] = '#';
	len = strlen(OgData);
	for(i = 0; i < len; i ++)
	{
		CgData[2 * (i + 1)] = OgData[i];
		CgData[(2 * i) + 3] = '#';
	}
	CgData[2 * (len + 1)] = '^';
	CgData[2 * (len + 1) + 1] = '\0';

	int MaxR = 0;
	int MaxI = 0;
	int cmp;
	int flag = 0;
	for(i = 0; i < 2 * (len + 1); i ++)
	{
		cmp = 1;
		if((MaxI + MaxR) > i)
		{
			cmp = MaxR - (i - MaxI);
		}
		while(1)
		{
			if(CgData[i + cmp] != CgData[i - cmp])
			{
				break;
			}
			else
			{
				cmp ++;
			}
		}
		if(MaxR < cmp)
		{
			MaxI = i; 
			MaxR = cmp;
		}
	}

	printf("�������Ϊ:\n");
	for(i = MaxI - MaxR + 2; i < MaxI + MaxR - 1; i = i + 2)
	{
		putchar(CgData[i]);
	}
	printf("\n");
	system("pause");
}

/*Ѱ������Ĵ�*/
/*���Ӷ�o(n)*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

char data[1006];
int Pcoord[30] = {0};
int Fcoord[30] = {0};
int Distt[30] = {0};

int main()
{
	int i, coord;
	int MaxDis = 0, flag;

	printf("�������ַ�����С��1000����\n");
	scanf("%s", &data[1]);

	for(i = 1; i <= strlen(data + 1); i ++)
	{
		coord = data[i] - 'a' + 1;
		if(Pcoord[coord] == 0)
		{
			Pcoord[coord] = i;
		}
		else
		{
			Fcoord[coord] = i;
		}
	}
	for(i = 1; i <= 26; i ++)
	{
		Distt[i] = Fcoord[i] - Pcoord[i] + 1;
	}
	for(i = 1; i <= 26; i ++)
	{
		if(MaxDis < Distt[i])
		{
			MaxDis = Distt[i];
			flag = Pcoord[i];
		}
	}

	printf("����ַ����ǣ�\n");
	while(MaxDis --)
	{
		putchar(data[flag ++]);
	}

	printf("\n");
	system("pause");
}

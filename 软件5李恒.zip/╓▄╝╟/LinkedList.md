# LinkedList

##遇到的问题

typedef的使用

```c
typedef struct LNode {
	ElemType data;
  	struct LNode *next;
} LNode, *LinkedList;
```

typedef struct LNode     LNode, _*LinkedList_;

__typedef 可以一个类别起两个名字__

__'*'与'->'优先级需注意__



_问：为何要用双重指针作为传递的参数_

_答：因为我们要在函数里面更改的是指针的指向，指针作为参数的话无法改变它的指向，因此需要传递指针的地址，即双重指针。_



```c
	LinkedList *L = NULL;
	InitList(L);
```

这样子是不可以的，NULL地址是0x000000，访问失败，不能作为参数。



##API实现后需要实现交互界面

#### menu()

1.Enum List

2.Create a List

3.Change a List

##### EnumList()

1.显示信息Name, Status, Loop

2.back

#####CreateList()

1.Name（不能重复）

2.Type

3.Data

##### OperateList()

1.Delete List

2.ReverseList

3.Find mid Mode



### 注意

Name用到了strcpy(dest, src)

使用getchar()进行选择的时候他获得的是字符应减去‘0‘

_最好使用scanf()固定形式的输入_



_问：输入错误数据类型的解决办法_

_答：fflush(stdin);清除缓存区（但是还是会有错误的数据值）_

疑问？（尚待解决）





_感觉对于单链表和双链表判断是否是存在环有点多此一举因此没有使用_
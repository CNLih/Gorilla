#include <reg52.h>

sbit Buzzer = P2^0;

void MyDelay(int time)    //ms
{
		unsigned int i = 0;
		for (i = 0; i < time * 150; i++);	
}

void main()
{
  while (1)
	{
		Buzzer = 1;
		delay(100);
		Buzzer = 0;
		delay(100);
  }
}